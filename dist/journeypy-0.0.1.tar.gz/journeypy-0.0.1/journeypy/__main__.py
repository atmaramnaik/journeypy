import sys
def main():
    sys.stdout.write("Success")


if __name__ == '__main__':
    main()

